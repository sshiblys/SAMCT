// Example: the parts of a parabola
function f(x) {
  return x * x - 2 * x - 2;
}

function g(x) {
  return -0.5 * x * x + 4;
}

function setup() {
  createCanvas(600, 400);
}

function draw() {
  background(245);
  drawAxes();
  // axis of symmetry x = -b / 2a = 1
  stroke(150);
  strokeWeight(2);
  drawingContext.setLineDash([8, 6]);
  line(sx(1), 0, sx(1), height);
  stroke(233, 113, 50);
  strokeWeight(3);
  plot(g);
  drawingContext.setLineDash([]);
  stroke(21, 96, 130);
  strokeWeight(4);
  plot(f);

  let r = sqrt(3);
  noStroke();
  fill(28, 29, 32);
  circle(sx(1), sy(-3), 12);
  fill(21, 96, 130);
  circle(sx(1 - r), sy(0), 12);
  circle(sx(1 + r), sy(0), 12);
  fill(233, 113, 50);
  circle(sx(0), sy(-2), 12);

  fill(28, 29, 32);
  textSize(16);
  text("vertex (1, -3)", sx(1) + 10, sy(-3) + 5);
  text("roots", sx(1 + r) + 8, sy(0) - 8);
  text("c = -2", sx(0) - 60, sy(-2));
  text("y = x² - 2x - 2   (dashed: y = -0.5x² + 4)", 10, 20);
}


// ---- grapher helpers: maths space -> screen space ----
const XMIN = -3, XMAX = 5;
const YMIN = -4, YMAX = 7;

function sx(x) {
  return map(x, XMIN, XMAX, 0, width);
}

function sy(y) {
  return map(y, YMIN, YMAX, height, 0);
}

function plot(fn) {
  noFill();
  beginShape();
  for (let px = 0; px <= width; px++) {
    let x = map(px, 0, width, XMIN, XMAX);
    let y = fn(x);
    if (!isFinite(y)) {
      endShape();
      beginShape();
      continue;
    }
    vertex(px, sy(y));
  }
  endShape();
}

function drawAxes() {
  strokeWeight(1);
  stroke(225);
  for (let x = ceil(XMIN); x <= XMAX; x++) line(sx(x), 0, sx(x), height);
  for (let y = ceil(YMIN); y <= YMAX; y++) line(0, sy(y), width, sy(y));
  stroke(120);
  line(0, sy(0), width, sy(0));
  line(sx(0), 0, sx(0), height);
}
