// Rose curve r = cos(k * angle), drawn with a function that returns a vector.
// Move the mouse left/right to change k.

function setup() {
  createCanvas(500, 500);
}

// Polar (length, angle) -> Cartesian vector
function polar(r, angle) {
  return createVector(r * cos(angle), r * sin(angle));
}

function draw() {
  background(245);
  let k = constrain(floor(map(mouseX, 0, width, 1, 9)), 1, 8);

  push();
  translate(width / 2, height / 2);
  noFill();
  stroke(28, 29, 32);
  strokeWeight(2);
  beginShape();
  for (let i = 0; i <= 720; i++) {
    let angle = map(i, 0, 720, 0, TWO_PI);
    let v = polar(180 * cos(k * angle), angle);
    vertex(v.x, v.y);
  }
  endShape();
  pop();

  noStroke();
  fill(28, 29, 32);
  textSize(16);
  text("r = cos(" + k + " × angle)", 12, 24);
}
