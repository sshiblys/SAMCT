// Example: y = mx + c
let m, c;

function linear(x) {
  return m * x + c;
}

function setup() {
  createCanvas(600, 400);
}

function draw() {
  background(245);
  drawAxes();
  m = map(mouseX, 0, width, -3, 3);
  c = map(mouseY, 0, height, 5, -5);
  stroke(21, 96, 130);
  strokeWeight(3);
  plot(linear);
  noStroke();
  fill(28, 29, 32);
  textSize(16);
  text("m = " + m.toFixed(2) + "   c = " + c.toFixed(2), 10, 20);
}


// ---- grapher helpers: maths space -> screen space ----
const XMIN = -10, XMAX = 10;
const YMIN = -6, YMAX = 6;

function sx(x) {
  return map(x, XMIN, XMAX, 0, width);
}

function sy(y) {
  return map(y, YMIN, YMAX, height, 0);
}

function plot(fn) {
  noFill();
  beginShape();
  for (let px = 0; px <= width; px++) {
    let x = map(px, 0, width, XMIN, XMAX);
    let y = fn(x);
    if (!isFinite(y)) {
      endShape();
      beginShape();
      continue;
    }
    vertex(px, sy(y));
  }
  endShape();
}

function drawAxes() {
  strokeWeight(1);
  stroke(225);
  for (let x = ceil(XMIN); x <= XMAX; x++) line(sx(x), 0, sx(x), height);
  for (let y = ceil(YMIN); y <= YMAX; y++) line(0, sy(y), width, sy(y));
  stroke(120);
  line(0, sy(0), width, sy(0));
  line(sx(0), 0, sx(0), height);
}
