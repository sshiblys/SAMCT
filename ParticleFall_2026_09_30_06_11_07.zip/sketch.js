// Example: the motion model
let p;

function setup() {
  createCanvas(600, 400);
  p = new Particle(50, 100);
  p.velocity = createVector(3, 0);
}

function draw() {
  background(245);
  p.acceleration.add(createVector(0, 0.1)); // gravity this frame
  p.update();
  p.display();

  if (p.position.y > height + 20) {
    p = new Particle(50, 100);
    p.velocity = createVector(3, 0);
  }
}

class Particle {
  constructor(x, y) {
    this.position = createVector(x, y);
    this.velocity = createVector(0, 0);
    this.acceleration = createVector(0, 0);
  }

  update() {
    this.velocity.add(this.acceleration);
    this.position.add(this.velocity);
    this.acceleration.mult(0);
  }

  display() {
    noStroke();
    fill(28, 29, 32);
    circle(this.position.x, this.position.y, 24);
  }
}
