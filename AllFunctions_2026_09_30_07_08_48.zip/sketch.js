// Function grapher: plots y = f(x) on maths axes.
// Keys 1-7 switch function. T toggles the tangent line at the mouse.
// Works in p5.js 1.x and 2.x.

const XMIN = -10, XMAX = 10;
const YMIN = -6, YMAX = 6;

let m = 1, c = 0, a = 0.2;   // parameters controlled by the mouse
let current = 0;
let showTangent = false;

const FUNCS = [
  { label: "y = mx + c  (mouse sets m and c)", fn: x => m * x + c },
  { label: "y = ax² - 3  (mouse x sets a)", fn: x => a * x * x - 3 },
  { label: "y = 2 sin(x + t)", fn: x => 2 * sin(x + frameCount * 0.05) },
  { label: "y = |x| - 3", fn: x => abs(x) - 3 },
  { label: "y = √x", fn: x => sqrt(x) },
  { label: "y = 1 / x", fn: x => 1 / x },
  { label: "y = 5 sin(x) / x", fn: x => 5 * sin(x) / x },
];

function setup() {
  createCanvas(600, 400);
}

function draw() {
  background(245);
  m = map(mouseX, 0, width, -3, 3);
  c = map(mouseY, 0, height, 5, -5);
  a = map(mouseX, 0, width, -1, 1);

  drawAxes();
  stroke(21, 96, 130);
  strokeWeight(3);
  plot(FUNCS[current].fn);
  if (showTangent) drawTangent(FUNCS[current].fn);

  noStroke();
  fill(28, 29, 32);
  textSize(14);
  text((current + 1) + ": " + FUNCS[current].label + "   · keys 1-7, T = tangent", 10, 20);
}

function keyPressed() {
  if (key >= "1" && key <= "7") current = int(key) - 1;
  if (key === "t" || key === "T") showTangent = !showTangent;
}

// maths x -> screen x
function sx(x) {
  return map(x, XMIN, XMAX, 0, width);
}

// maths y -> screen y (flipped, because screen y points down)
function sy(y) {
  return map(y, YMIN, YMAX, height, 0);
}

// Plot any function: for every pixel column, pixel -> x -> f(x) -> pixel
function plot(fn) {
  noFill();
  beginShape();
  for (let px = 0; px <= width; px++) {
    let x = map(px, 0, width, XMIN, XMAX);
    let y = fn(x);
    if (!isFinite(y)) {     // NaN or Infinity: break the line here
      endShape();
      beginShape();
      continue;
    }
    vertex(px, sy(y));
  }
  endShape();
}

function drawAxes() {
  strokeWeight(1);
  stroke(225);
  for (let x = ceil(XMIN); x <= XMAX; x++) line(sx(x), 0, sx(x), height);
  for (let y = ceil(YMIN); y <= YMAX; y++) line(0, sy(y), width, sy(y));
  stroke(120);
  line(0, sy(0), width, sy(0));
  line(sx(0), 0, sx(0), height);
}

// Slope of fn at x (central difference): a numerical derivative
function slope(fn, x) {
  let h = 0.001;
  return (fn(x + h) - fn(x - h)) / (2 * h);
}

function drawTangent(fn) {
  let x0 = map(mouseX, 0, width, XMIN, XMAX);
  let y0 = fn(x0);
  let s = slope(fn, x0);
  if (!isFinite(y0) || !isFinite(s)) return;
  stroke(233, 113, 50);
  strokeWeight(2);
  line(sx(XMIN), sy(y0 + s * (XMIN - x0)), sx(XMAX), sy(y0 + s * (XMAX - x0)));
  noStroke();
  fill(233, 113, 50);
  circle(sx(x0), sy(y0), 10);
  fill(28, 29, 32);
  text("slope = " + s.toFixed(2), 10, 40);
}
