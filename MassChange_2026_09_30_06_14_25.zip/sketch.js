// Example: forces and mass
let light, heavy;

function setup() {
  createCanvas(600, 400);
  restart();
}

function restart() {
  light = new Particle(50, 80, 1);
  heavy = new Particle(50, 220, 3);
}

function draw() {
  background(245);
  let wind = createVector(0.05, 0);

  for (let p of [light, heavy]) {
    let gravity = createVector(0, 0.02 * p.mass); // weight = mass x g
    p.applyForce(gravity);
    p.applyForce(wind);
    p.update();
    p.display();
  }

  noStroke();
  fill(28, 29, 32);
  textSize(16);
  text("mass 1 (blue) and mass 3 (orange), same wind. Click to restart.", 10, 20);
}

function mousePressed() {
  restart();
}

class Particle {
  constructor(x, y, mass) {
    this.position = createVector(x, y);
    this.velocity = createVector(0, 0);
    this.acceleration = createVector(0, 0);
    this.mass = mass;
  }

  applyForce(force) {
    let f = p5.Vector.div(force, this.mass); // a = F / m
    this.acceleration.add(f);
  }

  update() {
    this.velocity.add(this.acceleration);
    this.position.add(this.velocity);
    this.acceleration.mult(0);
  }

  display() {
    noStroke();
    if (this.mass > 1) fill(233, 113, 50);
    else fill(21, 96, 130);
    circle(this.position.x, this.position.y, 12 * sqrt(this.mass) + 12);
  }
}
