// Example: amplitude and period of a sine wave
function f(x) {
  return 2 * sin(x);
}

function g(x) {
  return sin(x);
}

function setup() {
  createCanvas(600, 400);
}

function draw() {
  background(245);
  drawAxes();
  stroke(150);
  strokeWeight(2);
  drawingContext.setLineDash([8, 6]);
  plot(g);
  drawingContext.setLineDash([]);
  stroke(21, 96, 130);
  strokeWeight(4);
  plot(f);

  // amplitude: from 0 to the peak at x = PI / 2
  stroke(233, 113, 50);
  strokeWeight(3);
  line(sx(HALF_PI), sy(0), sx(HALF_PI), sy(2));
  // period: from trough to trough, 3PI/2 to 7PI/2
  stroke(28, 29, 32);
  line(sx(3 * HALF_PI), sy(-2.6), sx(7 * HALF_PI), sy(-2.6));

  noStroke();
  fill(28, 29, 32);
  textSize(16);
  text("A = 2", sx(HALF_PI) + 8, sy(1));
  text("period = 2π ≈ 6.28", sx(2 * PI) + 10, sy(-2.3));
  text("y = 2 sin x   (dashed: y = sin x)", 10, 20);
}


// ---- grapher helpers: maths space -> screen space ----
const XMIN = -0.6, XMAX = 13.2;
const YMIN = -3, YMAX = 3;

function sx(x) {
  return map(x, XMIN, XMAX, 0, width);
}

function sy(y) {
  return map(y, YMIN, YMAX, height, 0);
}

function plot(fn) {
  noFill();
  beginShape();
  for (let px = 0; px <= width; px++) {
    let x = map(px, 0, width, XMIN, XMAX);
    let y = fn(x);
    if (!isFinite(y)) {
      endShape();
      beginShape();
      continue;
    }
    vertex(px, sy(y));
  }
  endShape();
}

function drawAxes() {
  strokeWeight(1);
  stroke(225);
  for (let x = ceil(XMIN); x <= XMAX; x++) line(sx(x), 0, sx(x), height);
  for (let y = ceil(YMIN); y <= YMAX; y++) line(0, sy(y), width, sy(y));
  stroke(120);
  line(0, sy(0), width, sy(0));
  line(sx(0), 0, sx(0), height);
}
