// Example: a function that draws (no return value)
function crosshair(x, y, size) {
  line(x - size, y, x + size, y);
  line(x, y - size, x, y + size);
}

function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(245);
  stroke(28, 29, 32);
  strokeWeight(2);
  crosshair(200, 200, 10);
  stroke(233, 113, 50);
  crosshair(mouseX, mouseY, 20);
}
